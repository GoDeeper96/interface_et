export interface ApiResponse {
  message: string
  data: Record<string, any>
  documentType: string
  filename: string
}
