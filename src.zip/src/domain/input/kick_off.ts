export interface KickOff {
  ciclo_de_dictado: number
  cursos_prerequisitos: string[]
  cantidad_creditos: number
  curso_evidencia: boolean
  carpeta_institucional: boolean
  acuerdos_generales: string[]
  acuerdos_sobre_evaluaciones: string[]
  acuerdos_finales: string[]
}
