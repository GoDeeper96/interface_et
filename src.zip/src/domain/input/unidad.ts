export interface Unidad {
  numero: number
  nombre: string
  duracion_semanas: number
  logros_de_aprendizaje: string[]
  contenidos: string[]
  actividades: string[]
  evaluacion: string
}
