import type { ActividadSemana } from "./actividad_semana";

export interface EsquemaActividad {
    actividades: ActividadSemana[]
}